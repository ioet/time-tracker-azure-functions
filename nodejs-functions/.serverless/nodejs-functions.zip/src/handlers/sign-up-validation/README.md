# Sign up Validation with Azure Function

## Description

This function restricts external users through email validation to allow only @ioet emails.

## Installation

The function doesn't require the installation of any external package. 

## Usage

Tha function is called by the Azure Connector API, so you need to configure in the Connector API.

## Credits

[Sign up Validation with Azure Function](https://github.com/ioet/time-tracker-ui/wiki/Sign-up-Validation-with-Azure-Function)
