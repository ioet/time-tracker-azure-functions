from ..shared_code.handle_events_trigger import main as handler

main = handler