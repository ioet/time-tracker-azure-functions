from ..shared_code import handle_events_trigger

main = handle_events_trigger.main